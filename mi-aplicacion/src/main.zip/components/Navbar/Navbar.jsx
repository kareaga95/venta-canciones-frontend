import React, { useState } from "react";
import "./Navbar.css";

const Navbar = ({ user, onSearch }) => {
    const [searchValue, setSearchValue] = useState("");
console.log("UUUUUSER", user);
    const handleSearch = () => {
        if (onSearch) {
            onSearch(searchValue);
        }
    };

    return (
        <nav className="navbar">
            <div className="navbar-container">
                <div className="navbar-logo">
                    <img src="/images/logo.png" alt="Logo" />
                    <a href="/" className="title">Song Launcher</a>
                </div>
                <div className="navbar-actions">
                    <input
                        className="search-input"
                        type="text"
                        value={searchValue}
                        onChange={(e) => setSearchValue(e.target.value)}
                        placeholder="Buscar..."
                    />
                    <button className="btn-search" onClick={handleSearch}>
                        Buscar
                    </button>
                </div>
                <ul className="navbar-right">
                    <li>
                        <a href="isArtist">¿Eres artista?</a>
                    </li>
                    {user ? (
                        <li className="username-display">
                            {user.username} {/* Mostrar el nombre del usuario */}
                        </li>
                    ) : (
                        <li>
                            <a className="login-link" href="login">Iniciar Sesión</a>
                        </li>
                    )}
                </ul>
            </div>
        </nav>
    );
};

export default Navbar;
